var app = {
  isReady: false,
  userName: null,
  initialize: function () {
    document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    if (!window.cordova) setTimeout(this.onDeviceReady.bind(this), 100);
  },
  onDeviceReady: function () { this.isReady = true; }
};

function $(id){ return document.getElementById(id); }

function showView(name){
  ['login', 'signup', 'dashboard'].forEach(v=>{
    $('view-' + v).classList.add('hidden');
    var tabId = 'tab' + v.charAt(0).toUpperCase() + v.slice(1);
    if ($(tabId)) $(tabId).classList.remove('active');
  });
  $('view-' + name).classList.remove('hidden');
  var tabId = 'tab' + name.charAt(0).toUpperCase() + name.slice(1);
  if ($(tabId)) $(tabId).classList.add('active');
  if (name === 'dashboard'){ $('tabDashboard').classList.remove('hidden'); }
}

function submitLogin(){
  var email = $('loginEmail').value.trim();
  var password = $('loginPassword').value.trim();
  if(!email || !password){ alert('Enter email & password'); return; }
  app.userName = email;
  $('welcomeText').innerText = 'Welcome back, ' + app.userName + '!';
  showView('dashboard');
}

function submitSignup(){
  var name = $('signupName').value.trim();
  var email = $('signupEmail').value.trim();
  var password = $('signupPassword').value.trim();
  if(!name || !email || !password){ alert('Fill all fields'); return; }
  app.userName = name;
  $('welcomeText').innerText = 'Thanks for signing up, ' + app.userName + '!';
  showView('dashboard');
}

function logout(){
  app.userName = null;
  $('loginEmail').value=''; $('loginPassword').value='';
  $('signupName').value=''; $('signupEmail').value=''; $('signupPassword').value='';
  $('tabDashboard').classList.add('hidden');
  showView('login');
}

app.initialize();
